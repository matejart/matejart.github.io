# DICETraffic CHANGELOG

This file is used to list changes made in each version of the DICETraffic
cookbook.


