#
# Cookbook Name:: DICETraffic
# Recipe:: spark_jobs
#
# Copyright 2017, XLAB d.o.o.
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions are met:
#
# 1. Redistributions of source code must retain the above copyright notice,
# this list of conditions and the following disclaimer.
#
# 2. Redistributions in binary form must reproduce the above copyright notice,
# this list of conditions and the following disclaimer in the documentation
# and/or other materials provided with the distribution.
#
# 3. Neither the name of the copyright holder nor the names of its contributors
# may be used to endorse or promote products derived from this software without
# specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
# AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
# IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
# ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
# LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
# CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
# SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
# INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
# CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
# ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
# POSSIBILITY OF SUCH DAMAGE.

rt_props = node['cloudify']['runtime_properties']
cache_path = node['DICE-BigData-Traffic']['cache_path']
install_path = File.join(node['DICE-BigData-Traffic']['install_path'], 'spark')
dicetraffic_user = node['DICE-BigData-Traffic']['user']
dicetraffic_group = node['DICE-BigData-Traffic']['group']

jobs = [
        #{
        #    :job_name => 'lpp travel time',
        #    :service_name => 'lpp_travel_time',
        #    :job_script => 'lpp_travel_time.py',
        #},
        {
            :job_name => 'heavy traffic computation',
            :service_name => 'heavy_traffic',
            :job_script => 'heavy_traffic.py',
        },
        {
            :job_name => 'typical traffic computation',
            :service_name => 'traffic_forecast',
            :job_script => 'traffic_forecast.py',
        },
    ]

directory install_path do
    owner dicetraffic_user
    group dicetraffic_group
    mode '0755'
    action :create
end

# install the python scripts that implement Spark jobs
python_runtime 'pyspark_jobs' do
    version '2'
    options dev_package: true
end

cache_path = node['DICE-BigData-Traffic']['cache_path']
bash 'install spark scripts' do
    cwd "#{cache_path}/spark"
    code <<-EOH
        cp *.py requirements.txt *.sh #{install_path}
        # TODO remove this
        echo "numpy == 1.12.1" > #{install_path}/requirements.txt
        # /TODO remove this
        chmod 644 *.py
        chmod 755 *.sh

        # This is to fix a java 8 install issue in Ubuntu 16.04
        if [ ! -e /etc/ssl/certs/java/cacerts ] && \
           [ -e /var/lib/dpkg/info/ca-certificates-java.postinst ]
        then
            /var/lib/dpkg/info/ca-certificates-java.postinst configure
        fi
    EOH
end

pip_requirements "#{install_path}/requirements.txt"

# customize the wrapper script for running Spark jobs
spark_master_fqdn = "spark://#{rt_props['spark_master_fqdn']}:7077"
template "#{install_path}/run_spark_cluster.sh" do
    source 'run_spark_cluster.sh.erb'
    mode '0755'
    variables(cassandra_fqdn: rt_props['cassandra_fqdn'],
        spark_master_fqdn: spark_master_fqdn)
    action :create
end

jobs.each do |job|

    service_name = "/etc/init/spark_job_#{job[:service_name]}.conf"
    job[:user] = dicetraffic_user
    job[:group] = dicetraffic_group
    job[:install_dir] = install_path
    template service_name do
        source 'spark_job.conf.erb'
        variables job
    end

    service "spark_job_#{job[:service_name]}" do
        action :enable
    end

end