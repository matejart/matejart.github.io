require 'serverspec'
set :backend, :exec

# verify the existence of the spark jobs installation folder
describe file('/var/lib/dicetraffic/spark') do
    it { should exist }
    it { should be_directory }
    it { should be_owned_by 'dicetraffic' }
    it { should be_grouped_into 'dicetraffic' }
    it { should be_mode 755 }
end

# validate the wrapper script for executing the jobs
describe file('/var/lib/dicetraffic/spark/run_spark_cluster.sh') do
    it { should exist }
    it { should be_file }
    it { should be_mode 755 }
    it { should contain(
        '--conf spark.cassandra.connection.host=cassandra22.local.lan') }
    it { should contain '--master spark://spark34.local.lan:7077' }
end

# validate Python packages
describe command('python -c "import numpy"') do
    its(:exit_status) { should eq 0 }
end

if os[:release] == '14.04'

    upstart_jobs = [
            ['heavy_traffic', 'heavy traffic computation',
                'heavy_traffic.py', 'spark_job_heavy_traffic.conf',
                'spark_job_heavy_traffic'],
            ['traffic_forecast', 'typical traffic computation',
                'traffic_forecast.py', 'spark_job_traffic_forecast.conf',
                'spark_job_traffic_forecast'],
        ]

    upstart_jobs.each do |job_descr|
        job_name = job_descr[0]
        job_description = "Spark job for #{job_descr[1]}"
        job_filename = job_descr[2]
        job_service = job_descr[3]
        job_service_name = job_descr[4]

        # does the Python script exist?
        describe file("/var/lib/dicetraffic/spark/#{job_filename}") do
            it { should exist }
            it { should be_file }
            it { should be_mode 644 }
        end

        # does the upstart job exist?
        describe file("/etc/init/#{job_service}") do
            it { should exist }
            it { should be_file }
            it { should be_mode 644 }
            it { should contain job_description }
            it { should contain "setuid dicetraffic" }
            it { should contain "setgid dicetraffic" }
            it { should contain "chdir /var/lib/dicetraffic/spark" }
            it { should contain "exec ./run_spark_cluster.sh #{job_filename}" }
        end

        describe service(job_service_name) do
            it { should be_enabled }
        end

    end
end
